<template>
    <div style="display: inline-block">
        <a class="btn" @click="toggleShow">مۇقاۋا رەسىم تاللاڭ</a>
        <my-upload field="img"
                   @crop-success="cropSuccess"
                   @crop-upload-success="cropUploadSuccess"
                   @crop-upload-fail="cropUploadFail"
                   v-model="show"
                   :width="480"
                   :height="320"
                   url="/photo_thumb"
                   :params="params"
                   :headers="headers"
                   img-format="png"
                   langType="ug"
        ></my-upload>
        <img :src="imgDataUrl" class="img-bordered">
        <input type="hidden" name="thumb" :value="imgDataUrl">
    </div>
</template>

<script>

    // import 'babel-polyfill'
    import myUpload from 'vue-image-crop-upload'

    export default {
        props:['avatar'],
        data() {
            return {
                show: false,
                params: {
                    _token: LEARNFANS.token,
                    name: 'avatar'
                },
                headers: {
                    smail: '*_~'
                },
                imgDataUrl: this.avatar
            }
        },
        components: {
            'my-upload': myUpload
        },
        methods: {
            toggleShow() {
                this.show = !this.show;
            },
            /**
             * crop success
             *
             * [param] imgDataUrl
             * [param] field
             */
            cropSuccess(imgDataUrl, field){
                this.imgDataUrl = imgDataUrl;
            },
            /**
             * upload success
             *
             * [param] jsonData  server api return data, already json encode
             * [param] field
             */
            cropUploadSuccess(jsonData, field){
                this.imgDataUrl = jsonData.url
                this.toggleShow()
            },
            /**
             * upload fail
             *
             * [param] status    server api return error status, like 500
             * [param] field
             */
            cropUploadFail(status, field){
                console.log('-------- upload fail --------');
                console.log(status);
                console.log('field: ' + field);
            }
        }
    }
</script>