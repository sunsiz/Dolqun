<?php $__env->startSection('title', 'يازما يوللاش'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="container-fluid" style="padding-right: 15px;padding-left: 15px;">
                    <div class="area-title hidden-xs hidden-sm">
                        <h3>بارلىق يازمىلار</h3>
                    </div>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row info-content">
                            <div class="col-md-4 col-sm-4 col-xs-12">
                                <a href="<?php echo e(route('articles.show', $post->id)); ?>">
                                    <img src="<?php echo e(asset($post->thumb)); ?>" class="img-responsive" alt="">
                                </a>
                            </div>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <h4><a href="<?php echo e(route('articles.show', $post->id)); ?>"><?php echo e($post->title); ?></a></h4>
                                <p class="hidden-xs">
                                    <?php echo e($post->description); ?>

                                </p>
                                <div class="content-status">
                                    <span><i class="fa fa-clock-o"></i>&nbsp;<?php echo e(Date::parse($post->updated_at)->diffForHumans(Date::now())); ?></span>
                                    <span><i class="fa fa-eye"></i>&nbsp;<?php echo e($post->clicks); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12">
                        <?php echo e($posts->render()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>