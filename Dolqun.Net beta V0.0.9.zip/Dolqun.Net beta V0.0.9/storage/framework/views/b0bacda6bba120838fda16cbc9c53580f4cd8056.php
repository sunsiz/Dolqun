<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>注册确认链接</title>
</head>
<body>
<h1>ياخشىمۇ سىز! 【Dolqun|蓝浪字幕组】 گە تېزىملاتقىنىڭىزنى قارشى ئئلىمىز</h1>
<p>
    تۆۋەندىكى ئۇلانمىنى بىسىپ تېزىملاشنى جەزىملەشتۈرۈڭ
    <a href="<?php echo e(route('confirmEmail', $user->activation_token)); ?>">
        <?php echo e(route('confirmEmail', $user->activation_token)); ?>

    </a>
</p>
<p>
    【Dolqun|蓝浪字幕组】
</p>
</body>
</html>