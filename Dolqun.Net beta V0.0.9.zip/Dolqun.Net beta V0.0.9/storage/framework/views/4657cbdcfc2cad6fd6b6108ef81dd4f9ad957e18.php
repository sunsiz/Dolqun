<?php $__env->startSection('title', 'كىرىش بېتى'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row searchForm">
        <form action="<?php echo e(route('search')); ?>">
            <div class="col-md-6 col-xs-10 col-md-offset-3 col-xs-offset-1">
                <button type="submit" class="btn izdesh">ئ‍ىزدەش</button>
                <input type="hidden" name="type" value="posts" id="searchType">
                <input type="text" class="" name="keywords"
                       placeholder="ھالقىلىق سۆزنى كىرگۈزۈڭ...">
                <ul class="searchType">
                    <h3><i class="fa fa-angle-down"></i> <span>مەزمۇن</span></h3>
                    <li data-value="filghetes">فىلغەت</li>
                    <li data-value="photos">رەسىم</li>
                </ul>
            </div>
        </form>

    </div>
    <div class="row">
        <div class="col-md-8">
            <div class="container-fluid" style="padding-right: 15px;padding-left: 15px;">
                <div class="area-title hidden-xs hidden-sm">
                    <h3>يېڭى يازمىلار</h3>
                </div>
                <div class="hidden-xs">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row info-content">
                            <div class="col-md-4 col-sm-4 col-xs-12">
                                <a href="<?php echo e(route('articles.show', $post->id)); ?>">
                                    <img src="<?php echo e(asset($post->thumb)); ?>" class="img-responsive" alt="">
                                </a>
                            </div>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <h4><a href="<?php echo e(route('articles.show', $post->id)); ?>"><?php echo e($post->title); ?></a></h4>
                                <p class="hidden-xs">
                                    <?php echo e($post->description); ?>

                                </p>
                                <div class="content-status">
                                    <span><i class="fa fa-clock-o"></i>&nbsp;<?php echo e(Date::parse($post->updated_at)->diffForHumans(Date::now())); ?></span>
                                    <span><i class="fa fa-eye"></i>&nbsp;<?php echo e($post->clicks); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(count($posts) >=10): ?>
                        <div class="col-md-12" style="text-align: center;margin-bottom: 30px;">
                            <a href="<?php echo e(route('post.list')); ?>" class="btn btn-outline-primary">تېخىمۇ كۆپ
                                يازمىلار</a>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="hidden-lg hidden-md hidden-sm">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($k >= 3): ?>
                            <?php break; ?>
                        <?php endif; ?>
                        <div class="row info-content">
                            <div class="col-md-4 col-sm-4 col-xs-12">
                                <a href="<?php echo e(route('articles.show', $post->id)); ?>">
                                    <img src="<?php echo e(asset($post->thumb)); ?>" class="img-responsive" alt="">
                                </a>
                            </div>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                                <h4><a href="<?php echo e(route('articles.show', $post->id)); ?>"><?php echo e($post->title); ?></a></h4>
                                <p class="hidden-xs">
                                    <?php echo e($post->description); ?>

                                </p>
                                <div class="content-status">
                                    <span><i class="fa fa-clock-o"></i>&nbsp;<?php echo e(Date::parse($post->updated_at)->diffForHumans(Date::now())); ?></span>
                                    <span><i class="fa fa-eye"></i>&nbsp;<?php echo e($post->clicks); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(count($posts) >=3): ?>
                        <div class="col-md-12" style="text-align: center;margin-bottom: 30px;">
                            <a href="<?php echo e(route('post.list')); ?>" class="btn btn-outline-primary">تېخىمۇ كۆپ
                                يازمىلار</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-md-4 left-area">
            <div class="container-fluid" style="padding-right: 15px;padding-left: 15px;">
                <div class="row">
                    <div class="lf-filghet" style="margin-bottom: 20px;overflow: hidden;">

                        <div class="col-md-12 area-title hidden-sm hidden-xs">
                            <h3>يېڭى سۆزلۈك </h3>
                        </div>

                        <div class="col-md-12 tags-list">
                            <?php $__currentLoopData = $filghets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$filghet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $colors = ['btn-primary', 'btn-danger', 'btn-info', 'btn-pink', 'btn-warning', 'btn-success'];
                                ?>
                                <a href="<?php echo e(route('filghetes.show', $filghet->id)); ?>" class="btn <?php echo e($colors[$k]); ?>">
                                    <span><?php echo e($filghet->ug); ?></span>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="col-md-12 hidden-sm hidden-xs area-title">
                        <h3>ئۇز رەسىم </h3>
                    </div>
                    <div class="hidden-xs">
                        <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="photos-list-item">
                                    <a href="<?php echo e(route('photos.show', $photo->id)); ?>">
                                        <img src="<?php echo e(asset($photo->thumb)); ?>" alt="" class="img-responsive">
                                    </a>
                                    <a href="<?php echo e(route('photos.show', $photo->id)); ?>"><h3><?php echo e($photo->title); ?></h3>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($photos) >=4): ?>
                            <div class="col-md-12" style="text-align: center;margin-bottom: 30px;">
                                <a href="<?php echo e(route('photo.list')); ?>" class="btn btn-outline-primary">تېخىمۇ كۆپ
                                    رەسىملەر</a>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="hidden-lg hidden-md hidden-sm">
                        <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($k >= 4): ?>
                                <?php break; ?>
                            <?php endif; ?>
                            <div class="col-md-6">
                                <div class="photos-list-item">
                                    <a href="<?php echo e(route('photos.show', $photo->id)); ?>">
                                        <img src="<?php echo e(asset($photo->thumb)); ?>" alt="" class="img-responsive">
                                    </a>
                                    <a href="<?php echo e(route('photos.show', $photo->id)); ?>"><h3><?php echo e($photo->title); ?></h3>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($photos) >=4): ?>
                            <div class="col-md-12" style="text-align: center;margin-bottom: 30px;">
                                <a href="<?php echo e(route('photo.list')); ?>" class="btn btn-outline-primary">تېخىمۇ كۆپ
                                    رەسىملەر</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(function () {
            $('.searchType li').on('click', function () {
                var searchType = $(this).attr('data-value');
                var searchText = $(this).text();
                $('.searchType h3 span').text(searchText);
                $('#searchType').attr('value', searchType)
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>