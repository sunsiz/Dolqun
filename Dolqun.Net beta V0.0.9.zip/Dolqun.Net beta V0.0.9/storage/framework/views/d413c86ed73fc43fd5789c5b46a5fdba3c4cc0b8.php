<?php $__env->startSection('title', $photo->title); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-3">
        <?php echo $__env->make('users.user-card', ['user' => $photo->user], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col-md-9">
        <div class="panel panel-default">
            <div class="panel-heading tac" style="border-bottom: none;">
                <h3 class="mt25"><?php echo e($photo->title); ?></h3>
            </div>
            <div class="panel-body post-body">
                <?php echo $photo->body; ?>

            </div>
        </div>

        
            
                
                    
                
                
                    
                        
                        
                        
                        
                        
                    
                
                    
                    
                        
                        
                            
                            
                        
                        
                    
                    
                
                    
                    
                        
                        
                    
                
            
            
                
            
        
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('highlight/highlight.pack.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('.post-body pre, .post-body code').each(function(i, block) {
                hljs.highlightBlock(block);
            });
            //编辑器的内的图片改为响应式图片类型
            $('.post-body img').addClass('img-responsive');
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>