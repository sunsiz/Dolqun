<?php $__env->startSection('title', 'يازما يوللاش'); ?>
<?php echo $__env->make('vendor.ueditor.assets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="row">
            <div class="page-header">
                <h3>
                    <span>ھالقىلىق سۆز</span>
                    <span class="text-pink"><?php echo e($keywords); ?></span>
                </h3>
            </div>

            <div class="row">
                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="photos-list-item">
                            <a href="<?php echo e(route('photos.show', $photo->id)); ?>">
                                <img src="<?php echo e(asset($photo->thumb)); ?>" alt="" class="img-responsive">
                            </a>
                            <a href="<?php echo e(route('photos.show', $photo->id)); ?>"><h3 style="font-size:14px;"><?php echo e($photo->title); ?></h3></a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>