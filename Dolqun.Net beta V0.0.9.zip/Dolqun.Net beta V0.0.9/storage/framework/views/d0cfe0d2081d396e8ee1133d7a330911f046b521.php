<div class="list-group mt25">
    <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="list-group-item <?php if(Request::route()->getName() == 'user.edit'): ?> active <?php endif; ?> "><i class="fa fa-edit"></i> ئارخىب تەھرىرلەش</a>
    <a href="<?php echo e(route('user.avatar', $user->id)); ?>" class="list-group-item <?php if(Request::route()->getName() == 'user.avatar'): ?> active <?php endif; ?> "><i class="fa fa-camera"></i> باش رەسىم ئۆزگەرتىش</a>
    <a href="<?php echo e(route('user.password', $user->id)); ?>" class="list-group-item <?php if(Request::route()->getName() == 'user.password'): ?> active <?php endif; ?> "><i class="fa fa-key"></i> پارول ئۆزگەرتىش</a>
</div>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is_admin', $user)): ?>
    <?php echo $__env->make('users.admin_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>