<?php $__env->startSection('title', 'كىرىش بېتى'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-6 col-md-offset-3 bg-white pd50 br3" style="margin-top: 60px;">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <form action="<?php echo e(route('login')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                        <input type="email" class="form-control" id="exampleInputEmail1" placeholder="ئاكونت" name="email" value="<?php echo e(old('email')); ?>">
                        <?php if($errors->has('email')): ?>
                            <span class="text-danger">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="پارول" name="password">
                        <?php if($errors->has('password')): ?>
                            <span class="text-danger">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group checkbox">
                        <label class="text-muted">
                            <input type="checkbox" name="remember">ئەستە ساقلىسۇن &nbsp;
                        </label>
                        
                    </div>
                    <button type="submit" class="btn btn-outline-primary btn-rounded btn-block">كىرىش</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>