<?php $__env->startSection('title', 'يازما يوللاش'); ?>
<?php echo $__env->make('vendor.ueditor.assets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="row">
            <div class="page-header">
                <h3>
                    <span>ھالقىلىق سۆز</span>
                    <span class="text-pink"><?php echo e($keywords); ?></span>
                </h3>
            </div>
            <div class="video-list">
                <ul>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="row">
                                <div class="col-md-4 col-sm-4 col-xs-12 video-img">
                                    <a href="<?php echo e(route('articles.show', $post->id)); ?>">
                                        <img src="<?php echo e(asset($post->thumb)); ?>" alt="" class="img-responsive">
                                    </a>
                                </div>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <div class="video-content">
                                        <a href="<?php echo e(route('articles.show', $post->id)); ?>">
                                            <h3><?php echo e($post->title); ?></h3>
                                        </a>
                                        <div class="video-star">
                                            <span class="color-warning"><i class="fa fa-star"></i></span>
                                            <span class="color-warning"><i class="fa fa-star"></i></span>
                                            <span class="color-warning"><i class="fa fa-star"></i></span>
                                            <span class="color-warning"><i class="fa fa-star"></i></span>
                                            <span><i class="fa fa-star"></i></span>
                                            <span class="video-star">9.0</span>
                                        </div>
                                        <p><?php echo e($post->description); ?></p>
                                        <div class="video-info">
                                            <span>
                                                <i class="fa fa-clock-o"></i>
                                                <?php echo e(Date::parse($post->created_at)->diffForHumans(Date::now())); ?>

                                            </span>
                                            <span>
                                                <i class="fa fa-eye"></i>
                                                <?php echo e($post->clicks); ?>

                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="load-more">
                    <button class="btn btn-outline-primary" style="margin: 0 auto;display: block">تېخىمۇ كۆپ ...
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>