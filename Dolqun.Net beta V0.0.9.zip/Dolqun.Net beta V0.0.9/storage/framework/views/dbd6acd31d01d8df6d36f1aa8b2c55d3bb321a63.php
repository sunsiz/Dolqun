<?php $__env->startSection('title', 'ئارخىب تەھرىرلەش'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-3">
                <?php echo $__env->make('users.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="col-md-9 mt25">
                <div class="panel panel-default">
                    <div class="panel-heading">ئارخىب تەھرىرلەش</div>
                    <div class="panel-body">
                        <form action="<?php echo e(route('user.update', $user->id)); ?>" method="post">
                            <?php echo e(method_field('PATCH')); ?>

                            <?php echo e(csrf_field()); ?>

                            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                <input type="text" class="form-control"  placeholder="ئاكونت" name="name" value="<?php echo e($user->name); ?>">
                                <?php if($errors->has('name')): ?>
                                    <span class="text-danger">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label class="radio-inline">
                                    <input type="radio" id="inlineCheckbox1" value="male" name="sex"
                                           <?php if($user->sex == 'male'): ?>
                                           checked
                                            <?php endif; ?>
                                    > ئاق ئاتلىق شاھزادە
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" id="inlineCheckbox2" value="female" name="sex"
                                           <?php if($user->sex == 'female'): ?>
                                           checked
                                            <?php endif; ?>
                                    > ساھىبجامال
                                </label>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" value="<?php echo e($user->email); ?>" disabled>
                            </div>
                            <button type="submit" class="btn btn-primary">ساقلاش</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>