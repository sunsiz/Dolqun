<?php $__env->startSection('title', 'يازما يوللاش'); ?>
<?php echo $__env->make('vendor.ueditor.assets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-3">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', Auth::user())): ?>
                    <?php echo $__env->make('users.sidebar', ['user' => Auth::user()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
            </div>
            <div class="col-md-9 mt25">
                <div class="panel panel-default">
                    <div class="panel-heading">يازما تېزىملىكى</div>
                    <div class="panel-body">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>يازما ماۋزۇسى</th>
                                <th>ھالىتى</th>
                                <th>ئاپتور</th>
                                <th>مەشخۇلات</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($post->id); ?></th>
                                    <td><a href="<?php echo e(route('posts.show', $post->id)); ?>"><?php echo e($post->title); ?></a></td>
                                    <td><?php echo e($post->status==1?'يوللانغان':'ئارگىنال'); ?></td>
                                    <td><?php echo e($post->author); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-info btn-sm">تەھرىرلەش</a>
                                            <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="post" style="display: inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button class="btn btn-danger btn-sm" type="submit">ئ‍ۆچۈرۈش</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($posts->render()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>