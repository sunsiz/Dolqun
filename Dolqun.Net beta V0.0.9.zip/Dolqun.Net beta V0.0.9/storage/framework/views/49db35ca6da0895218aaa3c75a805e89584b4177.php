<!-- 配置文件 -->
<script type="text/javascript" src="<?php echo e(asset('vendor/ueditor/ueditor.configs.dl.js')); ?>"></script>
<!-- 编辑器源码文件 -->
<script type="text/javascript" src="<?php echo e(asset('vendor/ueditor/ueditor.all.js')); ?>"></script>
<script type="text/javascript" charset="utf-8" src="<?php echo e(asset('vendor/ueditor/NUIedit.js')); ?>"> </script>
<script>
    window.UEDITOR_CONFIG.serverUrl = '<?php echo e(config('ueditor.route.name')); ?>'
</script>