<?php $__env->startSection('title', 'يازما يوللاش'); ?>
<?php echo $__env->make('vendor.ueditor.assets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-3">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', Auth::user())): ?>
                    <?php echo $__env->make('users.sidebar', ['user' => Auth::user()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
            </div>
            <div class="col-md-9 mt25">
                <div class="panel panel-default">

                    <div class="panel-body">

                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation"><a href="<?php echo e(route('posts.create')); ?>"><i class="fa fa-align-center"></i> مەزمۇن</a></li>
                            <li role="presentation" class="active"><a href="<?php echo e(route('filghetes.create')); ?>"><i class="fa fa-language"></i> فىلغەت</a></li>
                            <li role="presentation"><a href="<?php echo e(route('qamus.create')); ?>" ><i class="fa fa-globe"></i> قامۇس</a></li>
                            <li role="presentation"><a href="<?php echo e(route('photos.create')); ?>"><i class="fa fa-image"></i> رەسىم</a></li>
                        </ul>

                        <form action="<?php echo e(route('filghetes.store')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group <?php echo e($errors->has('ug') ? 'has-error' : ''); ?>">
                                <input type="text" class="form-control"  placeholder="ئۇيغۇرچە ئاتىلىشى" name="ug" value="<?php echo e(old('ug')); ?>">
                                <?php if($errors->has('ug')): ?>
                                    <span class="text-danger">
                                        <strong><?php echo e($errors->first('ug')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group <?php echo e($errors->has('zh') ? 'has-error' : ''); ?>">
                                <input type="text" class="form-control"  placeholder="خەنچە ئاتىلىشى" name="zh" value="<?php echo e(old('zh')); ?>">
                                <?php if($errors->has('zh')): ?>
                                    <span class="text-danger">
                                        <strong><?php echo e($errors->first('zh')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group <?php echo e($errors->has('other') ? 'has-error' : ''); ?>">
                                <input type="text" class="form-control"  placeholder="باشقا ئاتىلىشى" name="other" value="<?php echo e(old('other')); ?>">
                                <?php if($errors->has('other')): ?>
                                    <span class="text-danger">
                                        <strong><?php echo e($errors->first('other')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                                <textarea  class="form-control"  placeholder="ئىزاھات" name="description" rows="4"><?php echo e(old('description')); ?></textarea>
                                <?php if($errors->has('description')): ?>
                                    <span class="text-danger">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <button type="submit" class="btn btn-primary">قوشۇش</button>
                            <a href="<?php echo e(route('filghetes.index')); ?>" class="btn btn-default">تېزىملىككە قايتىش</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>