<div class="list-group">
    <a href="<?php echo e(route('posts.create')); ?>" class="list-group-item <?php if(Request::route()->getName() == 'posts.create'): ?> active <?php endif; ?> "><i class="fa fa-paper-plane"></i> مەزمۇن قوشۇش </a>
    <a href="<?php echo e(route('articles.index')); ?>" class="list-group-item <?php if(Request::route()->getName() == 'articles.index'): ?> active <?php endif; ?> "><i class="fa fa-list"></i> يازما تېزىملىكى</a>
    
</div>