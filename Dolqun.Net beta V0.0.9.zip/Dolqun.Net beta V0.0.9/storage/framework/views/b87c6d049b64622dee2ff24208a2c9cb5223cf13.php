<?php $__env->startSection('title', 'يازما يوللاش'); ?>
<?php echo $__env->make('vendor.ueditor.assets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="row">
            <div class="panel panel-default lf-border">
                <div class="panel-heading">
                    <h5 class="text-primary">
                        <i class="fa fa-angle-right"></i>
                        <i class="fa fa-angle-right"></i>
                        <span>
                                 ھالقىلىق سۆز
                            </span>
                        <span class="text-pink" style="font-size: 18px;">
                             [ <?php echo e($keywords); ?> ]
                        </span>
                        <span>
                            نىڭ ئىزدەش نەتىجىسى
                        </span>
                    </h5>
                </div>
                <?php $__currentLoopData = $filghets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filghet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel-heading">
                        <h4>
                            <a href="<?php echo e(route('filghetes.show', $filghet->id)); ?>" class="text-dark"> <?php echo e($filghet->ug); ?></a>
                            <span class="text-muted" style="font-size: 14px;">
                                <?php echo e($filghet->zh); ?>

                            </span>
                        </h4>
                    </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>