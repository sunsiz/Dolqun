<?php $__env->startSection('title', 'يازما يوللاش'); ?>
<?php echo $__env->make('vendor.ueditor.assets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-3">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', Auth::user())): ?>
                    <?php echo $__env->make('users.sidebar', ['user' => Auth::user()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
            </div>
            <div class="col-md-9 mt25">
                <div class="panel panel-default">

                    <div class="panel-body">

                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="<?php echo e(route('posts.create')); ?>"><i class="fa fa-align-center"></i> مەزمۇن</a></li>
                            <li role="presentation"><a href="<?php echo e(route('filghetes.create')); ?>"><i class="fa fa-language"></i> فىلغەت</a></li>
                            <li role="presentation"><a href="<?php echo e(route('qamus.create')); ?>" ><i class="fa fa-globe"></i> قامۇس</a></li>
                            <li role="presentation"><a href="<?php echo e(route('photos.create')); ?>"><i class="fa fa-image"></i> رەسىم</a></li>
                        </ul>

                        <form action="<?php echo e(route('posts.update', $post->id)); ?>" method="post">
                            <?php echo e(method_field('PATCH')); ?>

                            <?php echo e(csrf_field()); ?>

                            <div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                                <input type="text" class="form-control"  placeholder="ماۋزۇ (چوقۇم يازىسىز)" name="title" value="<?php echo e($post->title); ?>">
                                <?php if($errors->has('title')): ?>
                                    <span class="text-danger">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <thumb avatar="<?php echo e($post->thumb); ?>"></thumb>
                            </div>

                            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                                <textarea  class="form-control"  placeholder="يازما قىسقىچە مەزمۇنى" name="description" rows="4"><?php echo e($post->description); ?></textarea>
                                <?php if($errors->has('description')): ?>
                                    <span class="text-danger">
                                         <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group <?php echo e($errors->has('body') ? 'has-error' : ''); ?>">
                                <textarea id="container" name="body" type="text/plain"> <?php echo e($post->body); ?></textarea>
                                <?php if($errors->has('body')): ?>
                                        <span class="text-danger">
                                            <strong><?php echo e($errors->first('body')); ?></strong>
                                         </span>
                                <?php endif; ?>
                            </div>

                            <script>
                                var ue = UE.getEditor('container');

                                ue.ready(function() {
                                    ue.execCommand('serverparam', '_token', '<?php echo e(csrf_token()); ?>');
                                });
                            </script>

                            <div class="form-group">
                                <label class="radio-inline">
                                    <input type="radio" id="inlineCheckbox1" value="1" name="status" checked> بىۋاستە يوللاش
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" id="inlineCheckbox2" value="0" name="status"> ئارگىنال ساقلاش
                                </label>
                            </div>
                            <div class="form-group">
                            </div>
                            <button type="submit" class="btn btn-primary">ساقلاش</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>