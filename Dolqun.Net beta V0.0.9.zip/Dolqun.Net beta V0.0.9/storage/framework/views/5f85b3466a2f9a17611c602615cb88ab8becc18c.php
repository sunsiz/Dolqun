<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <title>Dolqun|دولقۇن تەرجىمىلىرى</title>

    <!-- Bootstrap -->
    <link href="<?php echo e(asset('css/bootstrap-3.3.7/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-3.3.7/css/bootstrap-rtl.css')); ?>">
    <link href="<?php echo e(mix('css/app.css')); ?>" rel="stylesheet">
    <script>
        <?php if(Auth::check()): ?>
            window.LEARNFANS = {
            name:"<?php echo e(Auth::user()->name); ?>",
            avatar:"<?php echo e(Auth::user()->avatar); ?>",
            token:"<?php echo e(csrf_token()); ?>"
        }
        <?php endif; ?>
    </script>
</head>
<body>
<div id="app">
    
    <div class="container-fluid lf-header">
        
        <div class="container p-logo">
            <div class="row">
                <div class="col-md-4" style="padding-top: 20px;">
                    <a href="<?php echo e(route('home')); ?>">
                        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="">
                    </a>
                </div>
                <div class="col-md-4"></div>
                <div class="col-md-4">
                    <?php if(auth()->guard()->check()): ?>
                        <div class="hasLogin">
                            ياخشىمۇسىز!
                            <a href="<?php echo e(route('user.edit', Auth::user()->id)); ?>" style="color: #fff;line-height: 100%;">
                                <?php echo e(Auth::user()->name); ?>

                            </a>
                            <a href="<?php echo e(route('logout')); ?>"> [ بېخەتەر چىكىنىش ]</a>
                        </div>
                    <?php else: ?>
                        <div class="noLogin">
                            <a href="<?php echo e(route('login')); ?>">[ كىرىش ]</a> |
                            <a href="<?php echo e(route('register')); ?>">[ تېزىملىتىش ]</a>
                        </div>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row" style="padding-top:60px;">
            <div class="col-md-12">
                <?php echo $__env->make('layouts.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="col-md-12">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <div class="container-fluid footer">
        <div class="container">
            <p>
                دولقۇن تەرجىمىلىرى | DolqunSub
            </p>
            <p class="hidden-xs">
                All Rights Reserved Dolqun.Net ©2016-2019 粤ICP备18109943号-1
                <br>
                深圳市理念文化传媒有限公司
            </p>
            <p class="hidden-lg hidden-md hidden-sm">
                All Rights Reserved Dolqun.Net
                <br>
                ©2016-2019 粤ICP备18109943号-1
                <br>
                深圳市理念文化传媒有限公司
            </p>
        </div>
    </div>
</div>
<script src="<?php echo e(mix('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>