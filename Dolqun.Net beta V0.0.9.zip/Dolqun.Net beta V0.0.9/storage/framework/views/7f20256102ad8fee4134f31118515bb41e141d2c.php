<?php $__env->startSection('title', 'يازما يوللاش'); ?>
<?php echo $__env->make('vendor.ueditor.assets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-3">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', Auth::user())): ?>
                    <?php echo $__env->make('users.sidebar', ['user' => Auth::user()], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
            </div>
            <div class="col-md-9 mt25">
                <div class="panel panel-default">

                    <div class="panel-body">

                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation"><a href="<?php echo e(route('posts.create')); ?>"><i class="fa fa-align-center"></i> مەزمۇن</a></li>
                            <li role="presentation" class="active"><a href="<?php echo e(route('filghetes.create')); ?>"><i class="fa fa-language"></i> فىلغەت</a></li>
                            <li role="presentation"><a href="<?php echo e(route('qamus.create')); ?>" ><i class="fa fa-globe"></i> قامۇس</a></li>
                            <li role="presentation"><a href="<?php echo e(route('photos.create')); ?>"><i class="fa fa-image"></i> رەسىم</a></li>
                        </ul>

                        <table class="table table-hover table-striped">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>ئۇيغۇرچە</th>
                                <th>خەنزۇچە</th>
                                <th>مەشخۇلات</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $filghetes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filghete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($filghete->id); ?></th>
                                    <td>
                                        <a href="<?php echo e(route('filghetes.show', $filghete->id)); ?>"><?php echo e($filghete->ug); ?></a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('filghetes.show', $filghete->id)); ?>"><?php echo e($filghete->zh); ?></a>
                                    </td>
                                    <th>
                                        <!-- Single button -->
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('filghetes.edit', $filghete->id)); ?>" class="btn btn-info btn-sm">تەھرىرلەش</a>
                                            <form action="<?php echo e(route('filghetes.destroy', $filghete->id)); ?>" method="post" style="display: inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button class="btn btn-danger btn-sm" type="submit">ئ‍ۆچۈرۈش</button>
                                            </form>
                                        </div>
                                    </th>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($filghetes->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>