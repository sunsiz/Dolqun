<?php $__env->startSection('title', 'باش رەسىم ئۆزگەرتىش'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-3">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user)): ?>
                    <?php echo $__env->make('users.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
            </div>
            <div class="col-md-9 mt25">
                <div class="panel panel-default">
                    <div class="panel-heading">باش رەسىم ئۆزگەرتىش</div>
                    <div class="panel-body">
                        <user-avatar avatar="<?php echo e(asset(Auth::user()->avatar)); ?>"></user-avatar>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>